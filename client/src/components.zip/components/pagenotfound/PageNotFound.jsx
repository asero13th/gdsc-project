import React from 'react'

const PageNotFound = () => {
  return (
    <div className='container' style={{minHeight: "33vh"}}><h3 className='text-center'>404 Page Not Found😞</h3></div>
  )
}

export default PageNotFound