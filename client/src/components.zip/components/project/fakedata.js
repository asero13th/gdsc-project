 export const fakedata = [
    {
        projectTitle: "App Development session 1",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
    {
        projectTitle: "App Development session 2",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium",

    },
    {
        projectTitle: "web development session 1",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
    {
        projectTitle: "web development session 2",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
 ]

 export const projectSessions = [
    {
        projectTitle: "App Development session 1",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
    {
        projectTitle: "App Development session 1",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
    {
        projectTitle: "App Development session 1",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem repellat error aliquam molestias eligendi praesentium"
    },
 ]