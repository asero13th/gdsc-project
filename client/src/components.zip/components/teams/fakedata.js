export const fakedata = [
    {
        startYear : 2020,
        endYear: 2021,
        teamMembers: [
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
        ]
    },
    {
        startYear : 2020,
        endYear: 2021,
        teamMembers: [
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
        ]
    },
    {
        startYear : 2020,
        endYear: 2021,
        teamMembers: [
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
            {
                name: "Gemechis",
                imgUrl: "",
                bio: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia, illo. In placeat excepturi magnam illo sequi quasi aliquid cum aspernatur, numquam suscipit officiis reprehenderit quibusdam neque aut rem voluptatem eaque",
            },
        ]
    },
    
]